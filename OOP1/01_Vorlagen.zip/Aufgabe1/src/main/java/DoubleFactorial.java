public class DoubleFactorial {
	public static void main(String[] args) {

	}
}
