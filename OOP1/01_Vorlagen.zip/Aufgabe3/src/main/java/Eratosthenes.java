public class Eratosthenes {
	public static void main(String[] args) {

	}
}
