
public class ImageProcessing {
	static int[][] invert(int[][] pixels) {
		// implement image inversion (negate all pixels)
		return pixels;
	}
	
	static int[][] rotate(int[][] pixels) {
		// implement image rotation (90 degrees to the right)
		return pixels;
	}
	
	static int[][] mirror(int[][] pixels) {
		// implement image mirroring (horizontal, left <-> right)
		return pixels;
	}
	
	static int[][] gray(int[][] pixels) {
		// optional task (advanced)
		return pixels;
	}
}
