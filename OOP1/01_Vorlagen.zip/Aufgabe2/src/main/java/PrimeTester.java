public class PrimeTester {
	public static void main(String[] args) {

	}
}
